const { default: mongoose } = require("mongoose");

const dbConnect = () =>{
    try {
        const conn = mongoose.connect(process.env.MONGOOSE_URL)
        console.log(conn);
    } catch (error) {
        // throw new Error(error);
        console.log('database error',error);
    }
} 

module.exports = dbConnect;