const User = require('../models/userModel');
const IntrestedCategory = require('../models/intrestedCategoryModel');
const bcrypt = require('bcryptjs');
const asyncHandler = require('express-async-handler');
const { generateToken } = require('../config/jwtToken');
const { generateRefreshToken } = require('../config/refreshToken');
const sequelize = require('../config/postgredbConnection');
const Country = require('../models/countryModel');


// register User
const createUser = asyncHandler( async (req, res) =>{
    try {
        const { first_name, last_name, country, mobile, password, email,with_country,compare_country  } = req.body;

        // Check if all required fields are present
        if (!first_name || !last_name || !password || !email || !country || !mobile) {
            return res.status(400).json({ message: 'All fields are required', status:false });
        }

        // Check if the user already exists
        const findUser = await User.findOne({ where: { email } });
        if(!findUser){
            // Hash the password
            const saltRounds = 10;
            const hashedPassword = await bcrypt.hash(password, saltRounds);

            //Create new user
            const newUser = await User.create({
                first_name,
                last_name,
                country,
                with_country,
                compare_country,
                mobile,
                password: hashedPassword,
                email
            });


            res.status(201).json({
                message: 'User created successfully',
                success:true,
                user: {
                    id: newUser.id,
                    first_name: newUser.first_name,
                    last_name: newUser.last_name,
                    country: newUser.country,
                    mobile: newUser.mobile,
                    email: newUser.email
                }
            });
            return;
        }else{
            res.json({
                message:"User Already Exist",
                success:false,
            });
            return;
        }
    }catch(error){
        throw new Error(error);
    }
});

// login user
const login = asyncHandler( async(req,res) => {
    try {
        const { email, password } = req.body;

        // Check if all required fields are present
        if (!email || !password) {
            return res.status(400).json({ message: 'All fields are required', status:false });
        }

        const findUser = await User.findOne({
            where: { email },
            include: [
                { model: Country, as: 'compareCountry', attributes: ['country_name', 'country_code', 'currency', 'currency_symbol'] },
                { model: Country, as: 'withCountry', attributes: ['country_name', 'country_code', 'currency', 'currency_symbol'] }
            ]
        });
        if(findUser && (await findUser.isPasswordMatched(password))){
            const refreshToken = await generateRefreshToken(findUser.id);
            await findUser.update({ refresh_token:refreshToken });
            res.cookie('refreshToken',refreshToken,{
                httpOnly:true,
                maxAge:72*60*1000,
            });

            res.json({
                message: 'User Logged In successfully',
                success:true,
                user: {
                    id: findUser.id,
                    first_name: findUser.first_name,
                    last_name: findUser.last_name,
                    country: findUser.country,
                    mobile: findUser.mobile,
                    email: findUser.email,
                    compare_country: findUser.compare_country ? findUser.compare_country.country_name : 'Unknown',
                    with_country: findUser.with_country ? findUser.with_country.country_name : 'Unknown',
                    token: generateToken(findUser.id)
                }
            });
            return;
        }else{
            res.json({
                message:"User Not Exist or Password dosn't match.",
                success:false,
            });
            return;
        }
    }catch(error){
        throw new Error(error);
    }
});

// update User
const updateUser = asyncHandler( async(req, res) => {
    try {
        const {id} = req.params;
        const updatedUser = await User.update({
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            mobile: req.body.mobile,
          }, {
            where: { id },
            returning: true,
            plain: true
          });
        res.json({
            message: 'User Updated successfully',
            success:true,
            updatedUser
        });
        return;
    } catch (error) {
        throw new Error(error);
    }
});

// get All Users
const getAllUsers = asyncHandler(async(req,res) => {
    try {
        const getUsers = await User.findAll();
        res.json({
            message: 'Users list get sucessfully',
            success:true,
            getUsers
        });
        return;
    } catch (error) {
        throw new Error(error);
    }
});

// user update intrested categories and update comparing countries
const updateUserDetails = asyncHandler(async(req, res)=>{
    try {
        const {id} = req.user;

        if(req.body.category_ids && req.body.category_ids.length > 0){
            
            const {category_ids} = req.body;
            
            // Iterate over each category_id
            for (const category_id of category_ids) {
                // Check if category exists for the user
                const existingCategory = await IntrestedCategory.findOne({ where: { user_id: id, category_id } });

                if (!existingCategory) {
                    // Insert new category
                    await IntrestedCategory.create({
                        user_id: _id,
                        category_id // Example create fields
                    });
                }
            }
        }

        if(req.body.compare_country && req.body.with_country){
            const {compare_country, with_country} = req.body;

            await User.update({ compare_country, with_country }, { where: { id } });
        }
        
        res.json({
            message: 'User Details Updated successfully',
            success:true
        });
        return;


    } catch (error) {
        throw new Error(error)
    }
});


// logout
const logout = asyncHandler( async(req, res) => {
    try {
        const cookie = req.cookies;
        if(!cookie?.refreshToken) throw new Error("no refresh token in cookies");
        const refreshToken =cookie.refreshToken;
        const user = await User.findOne({ where: { refresh_token:refreshToken } });
        if(!user){
            res.clearCookie('refreshToken',{
                httpOnly:true,
                secure:true,
            });
            return res.status(204); //forbidden
        }
        await user.update({ refresh_token: "" });
            res.clearCookie('refreshToken', {
            httpOnly: true,
            secure: true,
        });

        return res.sendStatus(204); //forbidden

    } catch (error) {
        throw new Error(error);
    }
});


module.exports = {createUser, login, getAllUsers, updateUser, updateUserDetails, logout};