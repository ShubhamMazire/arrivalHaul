const Country = require('../models/countryModel');
const asyncHandler = require('express-async-handler');
const stream = require('stream');
const csv = require('csv-parser');
const fs = require('fs');


// create Country
const createCountry = asyncHandler( async(req, res) => {
    try {
        const {country_name, country_code, currency, currency_symbol} =req.body;

        // Check if the category already exists
        const [newCountry, created] = await Country.findOrCreate({
            where: { country_name },
            defaults: { country_code, currency, currency_symbol },
        });
        if(created){
            
            res.status(201).json({
                message: 'Country created successfully',
                success:true,
                country: {
                    id: newCountry._id,
                    country_name: newCountry.country_name,
                    country_code: newCountry.country_code,
                    currency: newCountry.currency,
                    currency_symbol: newCountry.currency_symbol,
                    created_at: newCountry.createdAt,
                    updated_at: newCountry.updatedAt,
                }
            });
            return;
        }else{
            res.json({
                message:"Country Already Exist",
                success:false,
            });
            return;
        }
    } catch (error) {
        throw new Error(error);
    }
});


const uploadBulkCountryData = asyncHandler(async (req, res) => {
    try {
        if (req.file) { // If a CSV file is uploaded
            const results = [];
            const bufferStream = new stream.PassThrough();
            bufferStream.end(req.file.buffer);
            bufferStream
                .pipe(csv())
                .on('data', (data) => results.push(data))
                .on('end', async () => {
                    const bulkUpsertQuery = `
                        INSERT INTO countries (country_name, country_code, currency, currency_symbol)
                        VALUES %L
                        ON CONFLICT (country_name) DO UPDATE
                        SET
                        country_code = EXCLUDED.country_code,
                        currency = EXCLUDED.currency,
                        currency_symbol = EXCLUDED.currency_symbol
                        RETURNING *;
                    `;

                    const queryValues = results.map(country => [
                        country.country_name,
                        country.country_code,
                        country.currency,
                        country.currency_symbol,
                    ]);

                    const { rows } = await sequelize.query(bulkUpsertQuery, {
                        replacements: [queryValues],
                        type: sequelize.QueryTypes.INSERT,
                    });

                    res.status(201).json({
                        message: 'Countries uploaded successfully',
                        success: true,
                        countries: rows,
                    });
                });
        } else {
            res.status(400).json({
                message: 'No CSV file uploaded',
                success: false
            });
        }
    } catch (error) {
        res.status(500).json({
            message: 'Error uploading countries',
            success: false,
            error: error.message
        });
    }
});

// get All Users
const getAllCountries = asyncHandler(async(req,res) => {
    try {
        const countries = await Country.findAll({
            attributes: [
              'country_id',
              'country_name',
              'country_code',
              'currency',
              'currency_symbol'
            ],
          });
        res.json({
            message: 'Country list get sucessfully',
            success:true,
            countries
        });
        return;
    } catch (error) {
        throw new Error(error);
    }
});

module.exports = {createCountry, uploadBulkCountryData, getAllCountries};