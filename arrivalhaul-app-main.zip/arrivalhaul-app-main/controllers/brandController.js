const Brand = require('../models/brandModel');
const Source = require('../models/sourceModel');
const asyncHandler = require('express-async-handler');
const sequelize = require('../config/postgredbConnection');

// create Brand
const createBrand = asyncHandler( async(req, res) => {
    try {
        const {brand_name} =req.body;

        // Check if the brand already exists
        const findBrand = await Brand.findOne({ where: { brand_name } });
        if(!findBrand){
            
            //Create new brand
            const newBrand = await Brand.create({ brand_name });

            res.status(201).json({
                message: 'Brand created successfully',
                success:true,
                brand: {
                    brand_id: newBrand.brand_id,
                    brand_name: newBrand.brand_name
                }
            });
            return;
        }else{
            res.json({
                message:"Brand Already Exist",
                success:false,
            });
            return;
        }
    } catch (error) {
        throw new Error(error);
    }
});

// create source
const createSource = asyncHandler( async(req, res) => {
    try {
        const {source_name, brand_id} =req.body;

        // Check if the source already exists
        const findSource = await Source.findOne({ where: { source_name, brand_id } });
        if(!findSource){
            
            //Create new source
            const newSource = await Source.create({ source_name, brand_id });

            // Populate the brand_id to get the Brand details
            const populatedSource = await Source.findByPk(newSource.source_id, {
                include: [{ model: Brand, attributes: ['brand_name'] }]
            });

            res.status(201).json({
                message: 'Source created successfully',
                success: true,
                Source: {
                    source_id: newSource.source_id,
                    source_name: newSource.source_name,
                    brand_id: newSource.brand_id,
                    brand: populatedSource.Brand.brand_name,
                }
            });
            return;
        }else{
            res.json({
                message:"Source Already Exist",
                success:false,
            });
            return;
        }
    } catch (error) {
        throw new Error(error);
    }
});

const brandList = asyncHandler( async(req, res) => {
    
    try {
        const brands = await Brand.findAll({
            include: [{ model: Source, attributes: ['source_id', 'source_name'] }],
            attributes: {
                include: [[sequelize.literal('30'), 'discount']] // Add discount field with value 30
            }
        });
        res.json({
            message: 'brand list get sucessfully',
            success:true,
            brands
        });
        return;
    } catch (error) {
        throw new Error(error);
    }
});

module.exports = {createBrand, createSource, brandList};