const asyncHandler = require('express-async-handler');
const Country = require('../models/countryModel');
const Category = require('../models/categoryModel');
const SubCategory = require('../models/subCategoryModel');
const Brand = require('../models/brandModel');
const ProductImage = require('../models/productImagesModel');
const Source = require('../models/sourceModel');
const Product = require('../models/productModel');
const SourcePrice = require('../models/sourcePriceAvaibilityModel');
const User = require('../models/userModel');
const sequelize = require('../config/postgredbConnection');


const dashboardData = asyncHandler( async(req, res) => {
    try {
        //user details
        const userDetail = await User.findOne({
            where: {
                id:2
            }
        });
        
        const compareCountryDetails = await Country.findByPk(userDetail.compare_country);
        const withCountryDetails = await Country.findByPk(userDetail.with_country);

        const user = {
            user_id: userDetail.id,
            compare_country: {
              country_id: compareCountryDetails.country_id,
              country_name: compareCountryDetails.country_name,
              currency: compareCountryDetails.currency,
              currency_symbol: compareCountryDetails.currency_symbol,
              country_code: compareCountryDetails.country_code
            },
            with_country: {
              country_id: withCountryDetails.country_id,
              country_name: withCountryDetails.country_name,
              currency: withCountryDetails.currency,
              currency_symbol: withCountryDetails.currency_symbol,
              country_code: withCountryDetails.country_code
            }
          };

        // brand and source list
        const Brands = await Brand.findAll({
            attributes: {
                exclude: ['created_date', 'updated_date', 'is_active'] // Add attributes to exclude here
            },
            limit: 10
          });

          // Check if Brands is not an array (e.g., when only one result is returned)
        const brandsArray = Array.isArray(Brands) ? Brands : [Brands];

        const brands_list = brandsArray.map(brand => ({
            discount: 30, // Add the discount column with a value of 30  
        ...brand.toJSON()
        
        }));

        
        // const specificCategories = ['Category1', 'Category2', 'Category3'];
        const categories = await Category.findAll({
            attributes: {
                exclude: ['created_date', 'updated_date', 'is_active']
            },
            limit: 10
          });

        // Check if Brands is not an array (e.g., when only one result is returned)
        const categoryArray = Array.isArray(categories) ? categories : [categories];

        const category_list = categoryArray.map(brand => ({
            discount: 30, // Add the discount column with a value of 30
        ...brand.toJSON()
        }));

        // recommended for you
        const recommendProducts = await Product.findAll({
            where: {
                country_id: user.with_country.country_id
              },
            include: [
              { model: Category, attributes: ['category_name'] },
              { model: Brand, attributes: ['brand_name'] },
              { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
            ],
            limit: 10,
        });

        const recommendProductDetails = await Promise.all(recommendProducts.map(async (product) => {
            // Ensure related fields are populated and not null
            const category_name = product.category_id ? product.category_id.category_name : 'Unknown';
            const brand_name = product.brand_id ? product.brand_id.brand_name : 'Unknown';
            const country_name = product.country_id ? product.country_id.country_name : 'Unknown';
            

             // Get images
             const productImages = await ProductImage.findAll({
                where: {
                  product_id: product.product_id
                },
                attributes: ['image_url']
              });
              const images = productImages.map(img => img.image_url);

              
            const compareProductSources = await SourcePrice.findAll({
                where: {
                    product_id: product.product_id,
                    country_id: user.compare_country.country_id
                },
                include: [
                    { model: Source, attributes: ['source_name'] },
                    { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
                ]
            });
        
            // Retrieve only the first element from compareProductSources
            const compare_source = compareProductSources.length > 0 ? {
                source_name: compareProductSources[0].Source ? compareProductSources[0].Source.source_name : 'Unknown',
                country_code: compareProductSources[0].country ? compareProductSources[0].country.country_code : 'Unknown',
                country_currency: compareProductSources[0].country ? compareProductSources[0].country.currency_symbol : 'Unknown',
                compare_source_price: compareProductSources[0].price,
                with_source_price: null, // initialize with null
                discount: compareProductSources[0].discount,
                source_url: compareProductSources[0].source_url
            } : null;
        
            // Find product sources for the current product filtered by user.with_country.country_id
            const withProductSources = await SourcePrice.findAll({
                where: {
                    product_id: product.product_id,
                    country_id: user.with_country.country_id
                },
                include: [
                    { model: Source, attributes: ['source_name'] },
                    { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
                ]
            });
        
            // Retrieve only the first element from withProductSources
            const with_source = withProductSources.length > 0 ? {
                source_name: withProductSources[0].Source ? withProductSources[0].Source.source_name : 'Unknown',
                country_code: withProductSources[0].country ? withProductSources[0].country.country_code : 'Unknown',
                country_currency: withProductSources[0].country ? withProductSources[0].country.currency_symbol : 'Unknown',
                compare_source_price: null, // initialize with null
                with_source_price: withProductSources[0].price,
                source_url: withProductSources[0].source_url,
                discount: withProductSources[0].discount
            } : null;
        
            // Compare prices between compare_source and with_source
            if (compare_source && with_source && compare_source.source_name === with_source.source_name) {
                with_source.compare_source_price = compare_source.compare_source_price;
                compare_source.with_source_price = with_source.with_source_price;
            }

            return {
                product_id: product.product_id,
                product_unique_id: product.product_unique_id,
                product_name: product.product_name,
                product_description: product.product_description,
                model: product.model,
                is_favourite: false,
                category_name,
                brand_name,
                country_name,
                images: images.length > 0 ? images : 'https://eu.danielwellington.com/cdn/shop/products/4130ba3b2009851ee2571e4abdcf3bd09933b3b0.png?v=1679575039',
                compare_source,
                with_source
            };
        }));
       

        // popular Hauls
        const popularHaulProducts = await Product.findAll({
            where: {
                country_id: user.with_country.country_id
            },
            include: [
              { model: Category, attributes: ['category_name'] },
              { model: Brand, attributes: ['brand_name'] },
              { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
            ],
            limit: 10
          });

        const popularHaulProductDetails = await Promise.all(popularHaulProducts.map(async (product) => {
            // Ensure related fields are populated and not null
            const category_name = product.category_id ? product.category_id.category_name : 'Unknown';
            const brand_name = product.brand_id ? product.brand_id.brand_name : 'Unknown';
            const country_name = product.country_id ? product.country_id.country_name : 'Unknown';

             // Get images
             const productImages = await ProductImage.findAll({
                where: {
                  product_id: product.product_id
                },
                attributes: ['Image_url']
              });
              const images = productImages.map(img => img.Image_url);


             // Find product sources for the current product filtered by country_id
             const compareProductSources = await SourcePrice.findAll({
                where: {
                    product_id: product.product_id,
                    country_id: user.compare_country.country_id
                },
                include: [
                    { model: Source, attributes: ['source_name'] },
                    { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
                ]
            });
        
            // Retrieve only the first element from compareProductSources
            const compare_source = compareProductSources.length > 0 ? {
                source_name: compareProductSources[0].Source ? compareProductSources[0].Source.source_name : 'Unknown',
                country_code: compareProductSources[0].country ? compareProductSources[0].country.country_code : 'Unknown',
                country_currency: compareProductSources[0].country ? compareProductSources[0].country.currency_symbol : 'Unknown',
                compare_source_price: compareProductSources[0].price,
                with_source_price: null, // initialize with null
                discount: compareProductSources[0].discount,
                source_url: compareProductSources[0].source_url
            } : null;
        
            // Find product sources for the current product filtered by user.with_country.country_id
            const withProductSources = await SourcePrice.findAll({
                where: {
                    product_id: product.product_id,
                    country_id: user.with_country.country_id
                },
                include: [
                    { model: Source, attributes: ['source_name'] },
                    { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
                ]
            });
        
            // Retrieve only the first element from withProductSources
            const with_source = withProductSources.length > 0 ? {
                source_name: withProductSources[0].Source ? withProductSources[0].Source.source_name : 'Unknown',
                country_code: withProductSources[0].country ? withProductSources[0].country.country_code : 'Unknown',
                country_currency: withProductSources[0].country ? withProductSources[0].country.currency_symbol : 'Unknown',
                compare_source_price: null, // initialize with null
                with_source_price: withProductSources[0].price,
                source_url: withProductSources[0].source_url,
                discount: withProductSources[0].discount
            } : null;
        
            // Compare prices between compare_source and with_source
            if (compare_source && with_source && compare_source.source_name === with_source.source_name) {
                with_source.compare_source_price = compare_source.compare_source_price;
                compare_source.with_source_price = with_source.with_source_price;
            }

            return {
                product_id: product.product_id,
                product_unique_id: product.product_unique_id,
                product_name: product.product_name,
                product_description: product.product_description,
                model: product.model,
                is_favourite: false,
                category_name,
                brand_name,
                country_name,
                images: images.length > 0 ? images : 'https://eu.danielwellington.com/cdn/shop/products/4130ba3b2009851ee2571e4abdcf3bd09933b3b0.png?v=1679575038',
                compare_source,
                with_source
            };
        }));

        // Korea exclusive
        const countryExclusiveProducts = await Product.findAll({
            where: {
                country_id: user.with_country.country_id
            },
            include: [
              { model: Category, attributes: ['category_name'] },
              { model: Brand, attributes: ['brand_name'] },
              { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
            ],
            limit: 10
        });

        const countryExclusiveProductDetails = await Promise.all(countryExclusiveProducts.map(async (product) => {
            // Ensure related fields are populated and not null
            const category_name = product.category_id ? product.category_id.category_name : 'Unknown';
            const brand_name = product.brand_id ? product.brand_id.brand_name : 'Unknown';
            const country_name = product.country_id ? product.country_id.country_name : 'Unknown';

             // Get images
             const productImages = await ProductImage.findAll({
                where: {
                  product_id: product.product_id
                },
                attributes: ['Image_url']
              });
              const images = productImages.map(img => img.Image_url);

              // Find product sources for the current product filtered by country_id
              const compareProductSources = await SourcePrice.findAll({
                where: {
                    product_id: product.product_id,
                    country_id: user.compare_country.country_id
                },
                include: [
                    { model: Source, attributes: ['source_name'] },
                    { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
                ]
            });
        
            // Retrieve only the first element from compareProductSources
            const compare_source = compareProductSources.length > 0 ? {
                source_name: compareProductSources[0].Source ? compareProductSources[0].Source.source_name : 'Unknown',
                country_code: compareProductSources[0].country ? compareProductSources[0].country.country_code : 'Unknown',
                country_currency: compareProductSources[0].country ? compareProductSources[0].country.currency_symbol : 'Unknown',
                compare_source_price: compareProductSources[0].price,
                with_source_price: null, // initialize with null
                discount: compareProductSources[0].discount,
                source_url: compareProductSources[0].source_url
            } : null;
        
            // Find product sources for the current product filtered by user.with_country.country_id
            const withProductSources = await SourcePrice.findAll({
                where: {
                    product_id: product.product_id,
                    country_id: user.with_country.country_id
                },
                include: [
                    { model: Source, attributes: ['source_name'] },
                    { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
                ]
            });
        
            // Retrieve only the first element from withProductSources
            const with_source = withProductSources.length > 0 ? {
                source_name: withProductSources[0].Source ? withProductSources[0].Source.source_name : 'Unknown',
                country_code: withProductSources[0].country ? withProductSources[0].country.country_code : 'Unknown',
                country_currency: withProductSources[0].country ? withProductSources[0].country.currency_symbol : 'Unknown',
                compare_source_price: null, // initialize with null
                with_source_price: withProductSources[0].price,
                source_url: withProductSources[0].source_url,
                discount: withProductSources[0].discount
            } : null;
        
            // Compare prices between compare_source and with_source
            if (compare_source && with_source && compare_source.source_name === with_source.source_name) {
                with_source.compare_source_price = compare_source.compare_source_price;
                compare_source.with_source_price = with_source.with_source_price;
            }

            return {
                product_id: product.product_id,
                product_unique_id: product.product_unique_id,
                product_name: product.product_name,
                product_description: product.product_description,
                model: product.model,
                is_favourite: false,
                category_name,
                brand_name,
                country_name,
                images: images.length > 0 ? images : 'https://eu.danielwellington.com/cdn/shop/products/4130ba3b2009851ee2571e4abdcf3bd09933b3b0.png?v=1679575085',
                compare_source,
                with_source
            };
        }));

        // Define pagination parameters
        const page = 1;  // Current page number
        const perPage = 10;  // Number of items per page

        // Calculate offset
        const offset = (page - 1) * perPage;

        // Fetch daily discoveries products with pagination
        const dailyDiscoveriesProducts = await Product.findAll({
        where: {
            country_id: user.with_country.country_id
            },
        include: [
            { model: Category, attributes: ['category_name'] },
            { model: Brand, attributes: ['brand_name'] },
            { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
        ],
        offset,
        limit: perPage,
        order: [['product_id', 'ASC']]
        });

        // Process each product with its details
        const dailyDiscoveriesProductDetails = await Promise.all(dailyDiscoveriesProducts.map(async (product) => {
        // Ensure related fields are populated and not null
        const category_name = product.Category ? product.Category.category_name : 'Unknown';
        const brand_name = product.Brand ? product.Brand.brand_name : 'Unknown';
        const country_name = product.Country ? product.Country.country_name : 'Unknown';

        // Get images
        const productImages = await ProductImage.findAll({
            where: {
            product_id: product.product_id
            },
            attributes: ['Image_url']
        });
        const images = productImages.map(img => img.Image_url);

        // Find product sources for the current product filtered by country_id
        const compareProductSources = await SourcePrice.findAll({
            where: {
                product_id: product.product_id,
                country_id: user.compare_country.country_id
            },
            include: [
                { model: Source, attributes: ['source_name'] },
                { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
            ]
        });
    
        // Retrieve only the first element from compareProductSources
        const compare_source = compareProductSources.length > 0 ? {
            source_name: compareProductSources[0].Source ? compareProductSources[0].Source.source_name : 'Unknown',
            country_code: compareProductSources[0].country ? compareProductSources[0].country.country_code : 'Unknown',
            country_currency: compareProductSources[0].country ? compareProductSources[0].country.currency_symbol : 'Unknown',
            compare_source_price: compareProductSources[0].price,
            with_source_price: null, // initialize with null
            discount: compareProductSources[0].discount,
            source_url: compareProductSources[0].source_url
        } : null;
    
        // Find product sources for the current product filtered by user.with_country.country_id
        const withProductSources = await SourcePrice.findAll({
            where: {
                product_id: product.product_id,
                country_id: user.with_country.country_id
            },
            include: [
                { model: Source, attributes: ['source_name'] },
                { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
            ]
        });
    
        // Retrieve only the first element from withProductSources
        const with_source = withProductSources.length > 0 ? {
            source_name: withProductSources[0].Source ? withProductSources[0].Source.source_name : 'Unknown',
            country_code: withProductSources[0].country ? withProductSources[0].country.country_code : 'Unknown',
            country_currency: withProductSources[0].country ? withProductSources[0].country.currency_symbol : 'Unknown',
            compare_source_price: null, // initialize with null
            with_source_price: withProductSources[0].price,
            source_url: withProductSources[0].source_url,
            discount: withProductSources[0].discount
        } : null;
    
        // Compare prices between compare_source and with_source
        if (compare_source && with_source && compare_source.source_name === with_source.source_name) {
            with_source.compare_source_price = compare_source.compare_source_price;
            compare_source.with_source_price = with_source.with_source_price;
        }

        return {
            product_id: product.product_id,
            product_unique_id: product.product_unique_id,
            product_name: product.product_name,
            product_description: product.product_description,
            model: product.model,
            is_favourite: false,
            category_name,
            brand_name,
            country_name,
            images: images.length > 0 ? images : 'https://example.com/placeholder-image.jpg',
            compare_source,
            with_source
        };
        }));

        

        res.json({
            message: 'Dashboard Data get sucessfully',
            success:true,
            user,
            // countries,
            category_list,
            brands_list,
            recommend_products: recommendProductDetails,
            popular_haul:popularHaulProductDetails,
            country_exclusive: countryExclusiveProductDetails,
            daily_discoveries:{
                page,
                perPage,
                dailyDiscoveriesProductDetails
            }

        });


    } catch (error) {
        console.log(error);
        throw new Error(error);
    }
});

module.exports = {dashboardData};
