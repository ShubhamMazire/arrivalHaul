const Category = require('../models/categoryModel');
const SubCategory = require('../models/subCategoryModel');
const asyncHandler = require('express-async-handler');
const sequelize = require('../config/postgredbConnection');

// create Category
const createCategory = asyncHandler( async(req, res) => {
    try {
        const {category_name} =req.body;

        // Check if the category already exists
        const findCategory = await Category.findOne({category_name});
        if(!findCategory){
            
            //Create new category
            const findCategory = await Category.findOne({ where: { category_name } });

            res.status(201).json({
                message: 'Category created successfully',
                success:true,
                category: {
                    category_id: findCategory.category_id,
                    category_name: findCategory.category_name
                }
            });
            return;
        }else{
            res.json({
                message:"Category Already Exist",
                success:false,
            });
            return;
        }
    } catch (error) {
        throw new Error(error);
    }
});

// create SubCategory
const createSubCategory = asyncHandler( async(req, res) => {
    try {
        const {subcategory_name, category_id} =req.body;

        // Check if the category already exists
        const findSubCategory = await SubCategory.findOne({ where: { subcategory_name, category_id } });
        if(!findSubCategory){
            
            //Create new sub category
            const newSubCategory = await SubCategory.create({ subcategory_name, category_id });

            // Populate the category_id to get the category details
            const populatedSubCategory = await SubCategory.findByPk(newSubCategory.id, {
                include: [{ model: Category, attributes: ['category_name'] }]
            });

            res.status(201).json({
                message: 'SubCategory created successfully',
                success: true,
                subcategory: {
                    subcategory_id: newSubCategory.subcategory_id,
                    subcategory_name: newSubCategory.subcategory_name,
                    category_id: newSubCategory.category_id,
                    category: populatedSubCategory.category_id.category_name
                }
            });
            return;
        }else{
            res.json({
                message:"Sub Category Already Exist",
                success:false,
            });
            return;
        }
    } catch (error) {
        throw new Error(error);
    }
});

const categoryList = asyncHandler( async(req, res) => {
    
    try {
        const categories = await Category.findAll({
            include: [{ model: SubCategory, attributes: ['subcategory_id', 'subcategory_name'] }],
            attributes: {
                include: [[sequelize.literal('30'), 'discount']] // Add discount field with value 30
            }
        });
        res.json({
            message: 'Category list get sucessfully',
            success:true,
            categories
        });
        return;
    } catch (error) {
        throw new Error(error);
    }
});

module.exports = {createCategory, createSubCategory, categoryList};
