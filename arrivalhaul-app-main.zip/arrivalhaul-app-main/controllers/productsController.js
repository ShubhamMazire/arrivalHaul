const asyncHandler = require('express-async-handler');
const Product = require('../models/productModel');
const ProductImages = require('../models/productImagesModel');
const SourcePrice = require('../models/sourcePriceAvaibilityModel');
const productSource = require('../models/productSourceModel');
const s3 = require('../config/awsConnection');
const Category = require('../models/categoryModel');
const Brand = require('../models/brandModel');
const Country = require('../models/countryModel');
const Source = require('../models/sourceModel');
const User = require('../models/userModel');

const uploadImageToS3 = async (image) => {
    const params = {
        Bucket: process.env.AWS_BUCKET_NAME,
        Key: `${Date.now()}-${image.originalname}`, // Generate a unique key
        Body: image.buffer,
        ContentType: image.mimetype,
        ACL: 'public-read'
    };

    return s3.upload(params).promise();
};

const createProduct = asyncHandler( async (req, res) => {
    try {
        const {
            product_name, 
            product_description, 
            model, 
            category_id, 
            subcategory_id, 
            brand_id, 
            country_id, 
            // images
        } = req.body;

         // Create a new product
         const newProduct = await Product.create({
            product_name,
            product_description,
            model,
            category_id,
            subcategory_id,
            brand_id,
            country_id
        });


        // Add product images if any
        // if (req.files && req.files.length > 0) {
        //     const imageUploadPromises = req.files.map(uploadImageToS3);
        //     const imageResponses = await Promise.all(imageUploadPromises);

        //     const newProductImages = imageResponses.map(imageResponse => ({
        //         product_id: newProduct.product_idid,
        //         Image_url: imageResponse.Location, // S3 file URL
        //     }));

        //     await ProductImages.bulkCreate(newProductImages);
        // }

        const ProductImages = {
            product_id: newProduct.product_id,
            Image_url: "https://earthenhandmade.com/front/assets/images/slider/layers/butter2.png",
            isActive: 'active'
        }
        res.status(201).json({
            message: 'Product uploaded successfully',
            success: true,
            newProduct,
            ProductImages
        });

    } catch (error) {
        throw new Error(error);
    }
});

const createProductSource = asyncHandler( async (req, res) => {
    try {
        const {
            product_id, 
            source_id, 
            cost, 
            discount, 
            country_id, 
            source_url
        } = req.body;

         // Check if the source has already added this product for the same country
         const existingSourcePrice = await SourcePrice.findOne({
            where: {
                product_id,
                source_id,
                country_id
            }
        });

        if (existingSourcePrice) {
            return res.status(400).json({
                message: 'This source has already added this product for the specified country.',
                success: false
            });
        }

        // Create a new product
        const newSourcePrice = await SourcePrice.create({
            product_id,
            source_id,
            cost,
            discount,
            country_id,
            source_url
        });

        res.status(201).json({
            message: 'Product uploaded successfully',
            success: true,
            newSourcePrice
        });

    } catch (error) {
        throw new Error(error);
    }
});


const listProducts = asyncHandler(async (req, res) => {
    try {
        const products = await Product.findAll({
            include: [
                { model: Category, attributes: ['category_name'] },
                { model: Brand, attributes: ['brand_name'] },
                { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
            ]
        });


        const productDetails = await Promise.all(products.map(async (product) => {
            // Ensure related fields are populated and not null
            const category_name = product.category_id ? product.category_id.category_name : 'Unknown';
            const brand_name = product.brand_id ? product.brand_id.brand_name : 'Unknown';
            const country_name = product.country_id ? product.country_id.country_name : 'Unknown';

             // Get images
             const productImages = await ProductImages.findAll({
                where: {
                  product_id: product.product_id
                },
                attributes: ['Image_url']
              });
              const images = productImages.map(img => img.Image_url);


             // Find product sources for the current product filtered by country_id
             const compareProductSources = await SourcePrice.findAll({
                where: {
                    product_id: product.product_id
                },
                include: [
                    { model: Source, attributes: ['source_name'] }
                ]
            });

            const compare_sources = compareProductSources.map(source => ({
                source_name: source.source_id ? source.source_id.source_name : 'Unknown',
                price: source.price,
                discount: source.discount
            }));

            // const withProductSources = await SourcePrice.findAll({
            //     where: {
            //         product_id: product.product_id,
            //         country_id: user.with_country
            //     },
            //     include: [
            //         { model: Source, attributes: ['source_name'] },
            //         { model: Country, attributes: ['country_name', 'currency', 'currency_symbol', 'country_code'] }
            //     ]
            // });

            // const with_sources = withProductSources.map(source => ({
            //     source_name: source.source ? source.source.source_name : 'Unknown',
            //     country_code: source.country ? source.country.country_code : 'Unknown',
            //     cost: source.cost,
            //     discount: source.discount,
            //     source_url: source.source_url
            // }));


            return {
                product_id: product.product_id,
                product_unique_id: product.product_unique_id,
                product_name: product.product_name,
                product_description: product.product_description,
                model: product.model,
                category_name,
                brand_name,
                country_name,
                images: images,
                compare_sources,
                // with_sources
            };
        }));

        res.status(200).json({
            message: 'Products retrieved successfully',
            success: true,
            products: productDetails
        });

    } catch (error) {
        res.status(500).json({
            message: 'Error retrieving products',
            success: false,
            error: error.message
        });
    }
});



module.exports = { createProduct, listProducts, createProductSource };