const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const dotenv = require('dotenv').config();
const authRouter = require('./routes/authRoutes');
const categoryRouter = require('./routes/categoryRoutes');
const countryRouter = require('./routes/countryRoutes');
const brandRouter = require('./routes/brandRoutes');
const productsRouter = require('./routes/productsRoutes');
const userDashbaordRouter = require('./routes/userDashboardRoutes');
const { notFound, errorHandler } = require('./middlewares/errorHandler');
const cookieParser = require('cookie-parser');
const sequelize = require('./config/postgredbConnection');
const PORT = process.env.PORT || 5001;


const app = express();

// posgres connection using sequelize
sequelize;

// Use built-in middleware for JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use(morgan('dev'));
app.use(cors());

app.use('/api/auth', authRouter);
app.use('/api/category', categoryRouter);
app.use('/api/country', countryRouter);
app.use('/api/product', productsRouter);
app.use('/api/brand', brandRouter);
app.use('/api/user', userDashbaordRouter);

app.use(notFound);
app.use(errorHandler);

app.listen(PORT, () => {
    console.log(`Server is running on port: ${PORT}`);
});
