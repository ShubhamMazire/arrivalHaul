// models/subCategory.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/postgredbConnection'); // Your PostgreSQL connection instance
const Category = require('./categoryModel'); // Assuming you have a Category model

const SubCategory = sequelize.define('SubCategory', {
  subcategory_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  subcategory_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  category_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'category', // The table name in the database
      key: 'category_id',
    },
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true, // Set default value to true or false based on your requirements 
  }
}, {
    tableName: 'subcategory', // Optional: Define the table name explicitly
    timestamps: true,
    underscored: true,
    createdAt: 'created_date', // Custom name for createdAt column
    updatedAt: 'updated_date', // Custom name for updatedAt column
});

Category.hasMany(SubCategory, { foreignKey: 'category_id', targetKey: 'category_id' });
SubCategory.belongsTo(Category, { foreignKey: 'category_id', targetKey: 'category_id' });

module.exports = SubCategory;