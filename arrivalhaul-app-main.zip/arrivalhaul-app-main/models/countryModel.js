const { DataTypes } = require('sequelize'); // using sequelizing for postgres
const sequelize = require('../config/postgredbConnection');

const Country = sequelize.define('country', {
    country_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    country_name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    country_code: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    currency: {
        type: DataTypes.STRING,
        allowNull: false
    },
    currency_symbol: {
        type: DataTypes.STRING,
        allowNull: false
    },
    is_active: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true, // Set default value to true or false based on your requirements
    }
}, {
    timestamps: true, // Enable timestamps to create `createdAt` and `updatedAt` fields
    underscored: true, // Use snake_case for automatically added attributes (createdAt, updatedAt)
    createdAt: 'created_date', // Custom name for createdAt column
    updatedAt: 'updated_date', // Custom name for updatedAt column
  });

module.exports = Country;