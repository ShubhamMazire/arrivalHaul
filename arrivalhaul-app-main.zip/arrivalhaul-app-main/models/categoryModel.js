// models/category.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/postgredbConnection'); // Your PostgreSQL connection instance

const Category = sequelize.define('Category', {
  category_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  category_name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  is_active: {
    type: DataTypes.ENUM('active', 'inactive'),
    allowNull: false,
    defaultValue: 'active',
  }
}, {
    tableName: 'category', // Optional: Define the table name explicitly
    timestamps: true,
    underscored: true,
    createdAt: 'created_date', // Custom name for createdAt column
    updatedAt: 'updated_date', // Custom name for updatedAt column
});

module.exports = Category;