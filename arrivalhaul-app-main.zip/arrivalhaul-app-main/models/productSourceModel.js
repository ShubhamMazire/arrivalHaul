// models/productSource.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/postgredbConnection'); // Your PostgreSQL connection instance
const Source = require('./sourceModel');
const Product = require('./productModel');

const ProductSource = sequelize.define('ProductSource', {
  product_source_id: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
    primaryKey: true,
  },
  source_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'source',
      key: 'source_id',
    },
  },
  product_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'product',
      key: 'product_id',
    },
  },
  source_url: {
    type: DataTypes.STRING,
    trim: true,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true, // Set default value to true or false based on your requirements
  }
}, {
  tableName: 'product_source', // Optional: Define the table name explicitly
  timestamps: true,
  underscored: true,
  createdAt: 'created_date', // Custom name for createdAt column
  updatedAt: 'updated_date', // Custom name for updatedAt column
});

module.exports = ProductSource;