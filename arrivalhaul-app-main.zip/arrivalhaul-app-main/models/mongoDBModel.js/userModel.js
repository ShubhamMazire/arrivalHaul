const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { Schema } = mongoose;

// Declare the Schema of the Mongo model
var userSchema = new mongoose.Schema({
    firstName:{
        type:String,
        required:true,
    },
    lastName:{
        type:String,
        required:true,
    },
    email:{
        type:String,
        required:true,
        unique:true,
    },
    country:{
        type:String,
        required:true,
    },
    compare_country:{
        type: Schema.Types.ObjectId,
        ref: "country"
    },
    with_country:{
        type: Schema.Types.ObjectId,
        ref: "country"
    },
    mobile:{
        type:String,
        default: null,
        required:false,
    },
    password:{
        type:String,
        required:true,
    },
    role: {
        type: String,
        trim: true,
        default: 'user',
        enum: ['user', 'admin']
    },
    status: {
        type: String,
        trim: true,
        default: 'active',
        enum: ['active', 'in-active']
    },
    wishlist: {
        type: Schema.Types.ObjectId,
        ref: "Product"
    },
    refreshToken:{
        type:String
    }
    
},{
    timestamps: true
});

userSchema.methods.isPasswordMatched = async function(enteredPassword){
    return await bcrypt.compare(enteredPassword, this.password);
 }
//Export the model
module.exports = mongoose.model('User', userSchema);