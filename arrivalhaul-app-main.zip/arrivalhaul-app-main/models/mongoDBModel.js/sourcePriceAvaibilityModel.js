const mongoose = require('mongoose'); // Erase if already required
const { Schema } = mongoose;

// Declare the Schema of the Mongo model
var sourcePriceAvaibilitySchema = new mongoose.Schema({
    source_id: {
        type: Schema.Types.ObjectId,
        ref: "source"
    },
    product_id: {
        type: Schema.Types.ObjectId,
        ref: "product"
    },
    cost: {
        type:String,
        required:true,
    },
    discount: {
        type:String,
        required:true,
    },
    country_id: {
        type:Schema.Types.ObjectId,
        ref: "country"
    },
    source_url: {
        type:String,
    },
    isActive: {
        type: String,
        trim: true,
        default: 'active',
        enum: ['active', 'In-active']
    }
    
},{
    timestamps: true
});


//Export the model
module.exports = mongoose.model('source_price_avaibility', sourcePriceAvaibilitySchema);