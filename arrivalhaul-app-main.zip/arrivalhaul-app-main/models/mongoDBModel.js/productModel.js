const mongoose = require('mongoose'); 
const AutoIncrement = require('mongoose-sequence')(mongoose);
const { Schema } = mongoose;

// Declare the Schema of the Mongo model
var productSchema = new mongoose.Schema({
    product_unique_id: {
        type: String,
        unique: true,
        index: true
    },
    product_name: {
        type: String,
        required: true,
        trim: true
    },
    product_description: {
        type: String,
        trim: true
    },
    model: {
        type: String,
        trim: true
    },
    category_id: {
        type: Schema.Types.ObjectId,
        ref: "Category",
        required: true
    },
    subcategory_id: {
        type: Schema.Types.ObjectId,
        ref: "SubCategory"
    },
    brand_id: {
        type: Schema.Types.ObjectId,
        ref: "SubCategory",
        required: true
    },
    country_id: {
        type: Schema.Types.ObjectId,
        ref: "country"
    },
    isActive: {
        type: String,
        trim: true,
        default: 'active',
        enum: ['active', 'In-active']
    }
    
},{
    timestamps: true
});

// Add auto-increment plugin
productSchema.plugin(AutoIncrement, { inc_field: 'seq',start_seq: 1 });

// Middleware to set the product_unique_id
productSchema.post('save', function(doc, next) {
    if (!doc.product_unique_id) {
        doc.product_unique_id = `PROD-0${doc.seq}`;
        doc.save().then(() => next()).catch(err => next(err));
    } else {
        next();
    }
});


//Export the model
module.exports = mongoose.model('product', productSchema);