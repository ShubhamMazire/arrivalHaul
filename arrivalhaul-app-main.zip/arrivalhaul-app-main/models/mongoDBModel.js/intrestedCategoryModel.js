const mongoose = require('mongoose'); // Erase if already required
const { Schema } = mongoose;

// Declare the Schema of the Mongo model
var intrestedCategorySchema = new mongoose.Schema({
    user_id:{
        type: Schema.Types.ObjectId,
        ref: "User",
        required: true,
    },
    category_id: {
        type: Schema.Types.ObjectId,
        ref: "Category",
        required: true,
    },
    isActive: {
        type: String,
        trim: true,
        default: 'active',
        enum: ['active', 'In-active']
    }
    
},{
    timestamps: true
});


//Export the model
module.exports = mongoose.model('IntrestedCategory', intrestedCategorySchema);