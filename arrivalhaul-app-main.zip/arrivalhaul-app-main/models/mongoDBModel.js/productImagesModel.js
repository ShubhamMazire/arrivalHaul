const mongoose = require('mongoose'); // Erase if already required
const { Schema } = mongoose;

// Declare the Schema of the Mongo model
var productImagesSchema = new mongoose.Schema({
    product_id: {
        type: Schema.Types.ObjectId,
        ref: "products"
    },
    Image_url:{
        type:String,
        required:true,
    },
    isActive: {
        type: String,
        trim: true,
        default: 'active',
        enum: ['active', 'In-active']
    }
    
},{
    timestamps: true
});


//Export the model
module.exports = mongoose.model('product_images', productImagesSchema);