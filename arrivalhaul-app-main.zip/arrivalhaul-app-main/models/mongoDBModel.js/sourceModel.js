const mongoose = require('mongoose'); // Erase if already required
const { Schema } = mongoose;

// Declare the Schema of the Mongo model
var sourceSchema = new mongoose.Schema({
    source_name:{
        type:String,
        required:true,
    },
    brand_id: {
        type: Schema.Types.ObjectId,
        ref: "brand",
        required: true,
    },
    isActive: {
        type: String,
        trim: true,
        default: 'active',
        enum: ['active', 'In-active']
    }
    
},{
    timestamps: true
});


//Export the model
module.exports = mongoose.model('source', sourceSchema);