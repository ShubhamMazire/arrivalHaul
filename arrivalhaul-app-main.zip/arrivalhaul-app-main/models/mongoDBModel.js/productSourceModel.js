const mongoose = require('mongoose'); // Erase if already required
const { Schema } = mongoose;

// Declare the Schema of the Mongo model
var productSourceSchema = new mongoose.Schema({
    source_id: {
        type: Schema.Types.ObjectId,
        ref: "source"
    },
    product_id: {
        type: Schema.Types.ObjectId,
        ref: "product"
    },
    source_url: {
        type: String,
        trim: true
    },
    isActive: {
        type: String,
        trim: true,
        default: 'active',
        enum: ['active', 'In-active']
    }
    
},{
    timestamps: true
});


//Export the model
module.exports = mongoose.model('product_source', productSourceSchema);