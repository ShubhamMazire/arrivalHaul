const mongoose = require('mongoose'); // Erase if already required
const { Schema } = mongoose;

// Declare the Schema of the Mongo model
var countrySchema = new mongoose.Schema({
    country_name:{
        type:String,
        required:true,
        unique:true,
    },
    country_code:{
        type:String,
        required:true,
        unique:true,
    },
    currency:{
        type:String,
        required:true,
    },
    currency_symbol:{
        type:String,
        required:true,
    },
    isActive: {
        type: String,
        trim: true,
        default: 'active',
        enum: ['active', 'In-active']
    }
    
},{
    timestamps: true
});


//Export the model
module.exports = mongoose.model('country', countrySchema);