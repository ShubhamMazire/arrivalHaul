// models/intrestedCategory.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/postgredbConnection'); // Your PostgreSQL connection instance
const User = require('./userModel');
const Category = require('./categoryModel');

const IntrestedCategory = sequelize.define('IntrestedCategory', {
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id',
    },
  },
  category_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Category,
      key: 'categoey_id',
    },
  },
  is_active: {
    type: DataTypes.ENUM('active', 'inactive'),
    allowNull: false,
    defaultValue: 'active',
  }
}, {
  tableName: 'intrested_categories', // Optional: Define the table name explicitly
  timestamps: true,
  underscored: true,
  createdAt: 'created_date', // Custom name for createdAt column
  updatedAt: 'updated_date', // Custom name for updatedAt column
});

module.exports = IntrestedCategory;