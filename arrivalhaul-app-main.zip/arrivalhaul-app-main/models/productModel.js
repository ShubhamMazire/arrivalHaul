// models/product.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/postgredbConnection'); // Your PostgreSQL connection instance
const Category = require('./categoryModel');
const SubCategory = require('./subcategoryModel');
const Brand = require('./brandModel');
const Country = require('./countryModel');
const SourcePriceAvailability = require('./sourcePriceAvaibilityModel');

const Product = sequelize.define('Product', {
  product_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  product_unique_id: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
    primaryKey: true,
  },
  product_name: {
    type: DataTypes.STRING,
    allowNull: false,
    trim: true,
  },
  product_description: {
    type: DataTypes.STRING,
    trim: true,
  },
  model: {
    type: DataTypes.STRING,
    trim: true,
  },
  category_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'category',
      key: 'category_id',
    },
  },
  subcategory_id: {
    type: DataTypes.INTEGER,
    references: {
      model: 'subcategory',
      key: 'subcategory_id',
    },
  },
  brand_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'brand',
      key: 'brand_id',
    },
  },
  country_id: {
    type: DataTypes.INTEGER,
    references: {
      model: 'countries',
      key: 'country_id',
    },
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true, // Set default value to true or false based on your requirements
  }
}, {
    tableName: 'product', // Optional: Define the table name explicitly
    timestamps: true,
    underscored: true,
    createdAt: 'created_date', // Custom name for createdAt column
    updatedAt: 'updated_date', // Custom name for updatedAt column
});

Product.belongsTo(Category, { foreignKey: 'category_id', targetKey: 'category_id' });
Product.belongsTo(Brand, { foreignKey: 'brand_id', targetKey: 'brand_id' });
Product.belongsTo(Country, { foreignKey: 'country_id', targetKey: 'country_id' });
// Product.hasMany(SourcePriceAvailability, { foreignKey: 'product_id', targetKey: 'product_id' });

module.exports = Product;