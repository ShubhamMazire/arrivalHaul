// models/source.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/postgredbConnection'); // Your PostgreSQL connection instance
const Brand = require('./brandModel'); // Assuming you have a Brand model

const Source = sequelize.define('Source', {
  source_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  source_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  brand_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'brand', // The table name in the database
      key: 'brand_id',
    },
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true, // Set default value to true or false based on your requirements
    }
}, {
    tableName: 'source', // Optional: Define the table name explicitly
    timestamps: true,
    underscored: true,
    createdAt: 'created_date', // Custom name for createdAt column
    updatedAt: 'updated_date', // Custom name for updatedAt column
});

Brand.hasMany(Source, { foreignKey: 'brand_id', targetKey: 'brand_id' });
Source.belongsTo(Brand, { foreignKey: 'brand_id', targetKey: 'brand_id' });

module.exports = Source;