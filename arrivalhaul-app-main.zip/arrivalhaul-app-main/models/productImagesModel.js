// models/productImage.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/postgredbConnection'); // Your PostgreSQL connection instance
const Product = require('./productModel');

const ProductImage = sequelize.define('ProductImage', {
  product_image_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  product_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'product',
      key: 'product_id',
    },
  },
  Image_url: {
    type: DataTypes.STRING,
    allowNull: false,
  }
}, {
    tableName: 'product_image', // Optional: Define the table name explicitly
    timestamps: false,
    underscored: true
});

// Define associations
ProductImage.belongsTo(Product, { foreignKey: 'product_id', targetKey: 'product_id', as: 'productId' });

module.exports = ProductImage;