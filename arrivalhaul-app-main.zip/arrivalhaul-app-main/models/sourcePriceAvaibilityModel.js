// models/sourcePriceAvailability.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/postgredbConnection'); // Your PostgreSQL connection instance
const Product = require('./productModel');
const Country = require('./countryModel');
const Source = require('./sourceModel');

const SourcePriceAvailability = sequelize.define('SourcePriceAvailability', {
  source_price_availability_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  source_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'source', // The table name in the database
      key: 'source_id',
    },
  },
  product_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'product', // The table name in the database
      key: 'product_id',
    },
  },
  price: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  raw_price: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  discount: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  is_available: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true, // Set default value to true or false based on your requirements
  },
  country_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'countries', // The table name in the database
      key: 'country_id',
    },
  },
}, {
    tableName: 'source_price_availability', // Optional: Define the table name explicitly
    timestamps: true,
    underscored: true,
    createdAt: 'created_date', // Custom name for createdAt column
    updatedAt: 'updated_date', // Custom name for updatedAt column
});


SourcePriceAvailability.belongsTo(Source, { foreignKey: 'source_id', targetKey: 'source_id' });
SourcePriceAvailability.belongsTo(Country, { foreignKey: 'country_id', targetKey: 'country_id' });

module.exports = SourcePriceAvailability;