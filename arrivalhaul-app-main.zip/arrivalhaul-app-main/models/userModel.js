const { DataTypes } = require('sequelize'); // using sequelizing for postgres
const bcrypt = require('bcryptjs');
const sequelize = require('../config/postgredbConnection');
const Country = require('./countryModel');

// Declare the Schema of the Postgre model
const User = sequelize.define('user', {
    first_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    last_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    country: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    compare_country: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'Country',
        key: 'country_id',
      },
    },
    with_country: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'Country',
        key: 'country_id',
      },
    },
    mobile: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    role: {
      type: DataTypes.ENUM('user', 'admin'),
      allowNull: false,
      defaultValue: 'user',
    },
    status: {
      type: DataTypes.ENUM('active', 'in-active'),
      allowNull: false,
      defaultValue: 'active',
    },
    refresh_token: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    hooks: {
      beforeCreate: async (user) => {
        if (user.password) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
      beforeUpdate: async (user) => {
        if (user.changed('password')) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
    },
  });

  // Define associations
    User.belongsTo(Country, { foreignKey: 'compare_country', targetKey: 'country_id', as: 'compareCountry' });
    User.belongsTo(Country, { foreignKey: 'with_country', targetKey: 'country_id', as: 'withCountry' });
  
  User.prototype.isPasswordMatched = async function(enteredPassword) {
    return bcrypt.compare(enteredPassword, this.password);
  };
  
  module.exports = User;