const express = require('express');
const router = express.Router();
const {createUser, login, getAllUsers, updateUser, logout} =require('../controllers/userController');
const {authMiddlerware} = require('../middlewares/authMiddleware');

router.post('/login', login);
router.post('/register', createUser);
router.get('/get-all-users',authMiddlerware, getAllUsers);
router.put('/update-user/:id',authMiddlerware, updateUser);
router.get('/logout',logout);
module.exports = router;
