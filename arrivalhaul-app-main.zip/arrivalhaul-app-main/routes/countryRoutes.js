const express = require('express');
const router = express.Router();
const {authMiddlerware, isAdmin} = require('../middlewares/authMiddleware');
const { createCountry, uploadBulkCountryData, getAllCountries } = require('../controllers/countryController');
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage() });

router.post('/create', createCountry);
router.post('/bulk-create',upload.single('csvfile'),authMiddlerware,isAdmin, uploadBulkCountryData);
router.get('/show-list',authMiddlerware, getAllCountries);


module.exports = router;