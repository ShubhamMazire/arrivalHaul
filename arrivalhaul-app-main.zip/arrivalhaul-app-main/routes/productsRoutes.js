const express = require('express');
const router = express.Router();
const {authMiddlerware, isAdmin} = require('../middlewares/authMiddleware');
const { listProducts, createProduct, createProductSource } = require('../controllers/productsController');


router.get('/show-list', listProducts);
router.post('/create', createProduct);
router.post('/create-source', createProductSource);

module.exports = router;