const express = require('express');
const router = express.Router();
const {authMiddlerware, isAdmin} = require('../middlewares/authMiddleware');
const { brandList, createBrand, createSource } = require('../controllers/brandController');

// brand and source routes
router.get('/show-list', brandList);
router.post('/create', createBrand);
router.post('/source-create', createSource);


module.exports = router;