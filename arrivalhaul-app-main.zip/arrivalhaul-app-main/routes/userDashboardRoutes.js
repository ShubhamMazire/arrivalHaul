const express = require('express');
const router = express.Router();
const {authMiddlerware, isAdmin} = require('../middlewares/authMiddleware');
const { dashboardData } = require('../controllers/userDashboardController');
const { updateUserDetails } = require('../controllers/userController');

router.get('/dashboard-data', dashboardData);
router.post('/update-user-detail',updateUserDetails)

module.exports = router;