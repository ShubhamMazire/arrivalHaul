const express = require('express');
const router = express.Router();
const {authMiddlerware, isAdmin} = require('../middlewares/authMiddleware');
const { createCategory, createSubCategory, categoryList } = require('../controllers/categoryController');

// category routes
router.get('/show-list', categoryList);
router.post('/create', createCategory);
router.post('/subcategory-create', createSubCategory);

module.exports = router;
